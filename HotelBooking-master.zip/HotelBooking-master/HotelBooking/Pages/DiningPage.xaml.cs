﻿using HotelBooking.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HotelBooking.Pages
{
    /// <summary>
    /// Interaction logic for DiningPage.xaml
    /// </summary>
    public partial class DiningPage : Page
    {
        private static string westernName;
        private static double westernCost;
        private static string chineseName;
        private static double chineseCost;
        private static string italianName;
        private static double italianCost;
        public DiningPage()
        {
            InitializeComponent();
            foreach (var item in MainWindow.resource.dining)
            {
                if (item.restrauntType.Equals("Western"))
                {
                    westernName = item.restrauntType;
                    westernCost = item.cost;
                }
                else if (item.restrauntType.Equals("Chinese"))
                {
                    chineseName = item.restrauntType;
                    chineseCost = item.cost;
                }
                else if (item.restrauntType.Equals("Italian"))
                {
                    italianName = item.restrauntType;
                    italianCost = item.cost;
                }
            }
        }

        private void WesternButton_Click(object sender, RoutedEventArgs e)
        {
            //scheduler to loop through all the room ids to check for availability
            bool bookingFull = false;
            int facilityId = 0;
            foreach (var item in MainWindow.resource.dining)
            {
                if (item.restrauntType.Equals("Western"))
                {
                    foreach (var ids in item.tableId)
                    {
                        foreach (var booking in ids.bookings)
                        {
                            if (booking.dates == null)
                            {
                                bookingFull = false;
                                facilityId = ids.id;
                                break;
                            }
                            //Booking full on selected date
                            else if (WesternBooking.SelectedDate.Equals(booking.dates))
                            {
                                bookingFull = true;
                            }
                            else if (WesternBooking.SelectedDate != booking.dates)
                            {
                                bookingFull = false;
                                facilityId = ids.id;
                                break;
                            }
                        }
                    }
                    if (facilityId > 0) break;
                }
            }
            //when booking dates not chosen, user is alerted to select the dates
            if (WesternBooking == null )
            {
                MessageBox.Show("Please choose your booking dates");
            }
            //Check if booking is full on selected dates for all selected facilities
            else if (bookingFull == true)
            {
                MessageBox.Show("The booking's that you've chosen are currently full");
            }
            //Add item to Cart
            else
            {
                //Add to cart
                CartItem Item = new CartItem()
                {
                    itemName = westernName,
                    BookingStart = WesternBooking.SelectedDate.Value,
                    BookingEnd = WesternBooking.SelectedDate.Value,
                    cost = westernCost,
                    itemId = facilityId
                };
                MainWindow.Cart.Add(Item);
                WesternButton.IsEnabled = false;
            }
        }

        private void ChineseButton_Click(object sender, RoutedEventArgs e)
        {
            //scheduler to loop through all the room ids to check for availability
            bool bookingFull = false;
            int facilityId = 0;
            foreach (var item in MainWindow.resource.dining)
            {
                if (item.restrauntType.Equals("Chinese"))
                {
                    foreach (var ids in item.tableId)
                    {
                        foreach (var booking in ids.bookings)
                        {
                            if (booking.dates == null)
                            {
                                bookingFull = false;
                                facilityId = ids.id;
                                break;
                            }
                            //booking full on selected dates
                            else if (ChineseBooking.SelectedDate.Equals(booking.dates))
                            {
                                bookingFull = true;
                            }
                            else if (ChineseBooking.SelectedDate != booking.dates)
                            {
                                bookingFull = false;
                                facilityId = ids.id;
                                break;
                            }
                        }
                    }
                    if (facilityId > 0) break;
                }
            }
            //when booking dates not chosen, user is alerted to select the dates
            if (ChineseBooking.SelectedDate == null)
            {
                MessageBox.Show("Please choose your booking dates");
            }
            //Check if booking is full on selected dates for all selected facilities
            else if (bookingFull == true)
            {
                MessageBox.Show("The booking's that you've chosen are currently full");
            }
            //Add item to Cart
            else
            {
                //Add to cart
                CartItem Item = new CartItem()
                {
                    itemName = chineseName,
                    BookingStart = ChineseBooking.SelectedDate.Value,
                    BookingEnd = ChineseBooking.SelectedDate.Value,
                    cost = chineseCost,
                    itemId = facilityId
                };
                MainWindow.Cart.Add(Item);
                ChineseButton.IsEnabled = false;
            }
        }

        private void ItalianButton_Click(object sender, RoutedEventArgs e)
        {
            //scheduler to loop through all the room ids to check for availability
            bool bookingFull = false;
            int facilityId = 0;
            foreach (var item in MainWindow.resource.dining)
            {
                if (item.restrauntType.Equals("Italian"))
                {
                    foreach (var ids in item.tableId)
                    {
                        foreach (var booking in ids.bookings)
                        {
                            if (booking.dates == null)
                            {
                                bookingFull = false;
                                facilityId = ids.id;
                                break;
                            }
                            //booking full on selected dates
                            else if (ItalianBooking.SelectedDate.Equals(booking.dates))
                            {
                                bookingFull = true;
                            }
                            else if (ItalianBooking.SelectedDate != booking.dates)
                            {
                                bookingFull = false;
                                facilityId = ids.id;
                                break;
                            }
                        }
                    }
                    if (facilityId > 0) break;
                }
            }
            //when booking dates not chosen, user is alerted to select the dates
            if (ItalianBooking.SelectedDate == null)
            {
                MessageBox.Show("Please choose your booking dates");
            }
            //Check if booking is full on selected dates for all selected facilities
            else if (bookingFull == true)
            {
                MessageBox.Show("The booking's that you've chosen are currently full");
            }
            //Add item to Cart
            else
            {
                //Add to cart
                CartItem Item = new CartItem()
                {
                    itemName = italianName,
                    BookingStart = ItalianBooking.SelectedDate.Value,
                    BookingEnd = ItalianBooking.SelectedDate.Value,
                    cost = italianCost,
                    itemId = facilityId
                };
                MainWindow.Cart.Add(Item);
                ItalianButton.IsEnabled = false;
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Cart.Clear();
            WesternButton.IsEnabled = true;
            ChineseButton.IsEnabled = true;
            ItalianButton.IsEnabled = true;
        }
    }
}
