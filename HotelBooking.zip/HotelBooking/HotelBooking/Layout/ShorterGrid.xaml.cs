﻿using HotelBooking.Pages;
using System.Windows;
using System.Windows.Controls;

namespace HotelBooking.Facility
{
    /// <summary>
    /// Interaction logic for ShorterGrid.xaml
    /// </summary>
    public partial class ShorterGrid : UserControl
    {
        private static string theGoldenName;
        private static double theGoldenCost;
        private static string theVintageName;
        private static double theVintageCost;
        private static string theWillowName;
        private static double theWillowCost;

        public ShorterGrid()
        {
            InitializeComponent();
            foreach (var item in MainWindow.resource.ballRooms)
            {
                if (item.ballroomType.Equals("The Golden"))
                {
                    theGoldenName = item.ballroomType;
                    theGoldenCost = item.cost;
                }
                else if (item.ballroomType.Equals("The Vintage"))
                {
                    theVintageName = item.ballroomType;
                    theVintageCost = item.cost;
                }
                else if (item.ballroomType.Equals("The Willow"))
                {
                    theWillowName = item.ballroomType;
                    theWillowCost = item.cost;
                }
            }
        }

        private void BookNowButton_Click(object sender, RoutedEventArgs e)
        {
            Model model = Application.Current.Properties["PageData"] as Model;
            if (model.Name == "Classic Room")
            {
                MessageBox.Show("Classic");
            }
            else if (model.Name == "Deluxe Room")
            {
                MessageBox.Show("Deluxe");
            }
            else if (model.Name == "Prestige Room")
            {
                MessageBox.Show("Prestige");
            }
            else if (model.Name == "The Golden")
            {
                MessageBox.Show("Golden");
            }
            else if (model.Name == "The Vintage")
            {
                MessageBox.Show("Vintage");
            }
            else if (model.Name == "The Willow")
            {
                MessageBox.Show("Willow");
            }
        }
    }
}
